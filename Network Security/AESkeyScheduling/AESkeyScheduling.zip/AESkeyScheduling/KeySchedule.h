#include <stdio.h>

void Expand(const unsigned char input[], unsigned char output[]);


